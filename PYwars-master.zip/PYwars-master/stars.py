from graphics import *
import random



windowX = 1000
windowY = 500


stars = [Circle(Point(0, 0), 0)]*300
starColors = [
    color_rgb(255, 255, 255),
    color_rgb(229, 229, 229),
    color_rgb(155, 193, 247),
    color_rgb(50, 134, 252)
]
def main():

    win = GraphWin("Stars Experiment", windowX, windowY)
    win.setBackground(color_rgb(0, 0, 0))

    for star in stars:
        star = Circle(Point(random.randint(0, windowX), random.randint(0, windowY)), 1)
        star.setFill(starColors[random.randint(0, len(starColors) - 1)])
        star.draw(win)

    win.getMouse()
    win.close()


if __name__ == "__main__":
    main()