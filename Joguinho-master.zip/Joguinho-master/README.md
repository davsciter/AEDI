# Joguinho
Jogo criado em Python usando a biblioteca graphics.py feito por Lucas Avila e Gabriela Suita.
