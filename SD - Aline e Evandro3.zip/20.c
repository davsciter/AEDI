#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"

int main(int argc, char const *argv[]) {
        char buf[] = "123456789";
        char troca;
        int i, tam = 9;

        for (i = 0; i < tam/2; i++) {
                troca = buf[i];
                buf[i] = buf[tam-1-i];
                buf[tam-1-i] = troca;
                show(buf,tam);
        }
//        show(buf,tam);

        return 0;
}
