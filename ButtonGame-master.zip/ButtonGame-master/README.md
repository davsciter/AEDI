# ButtonGame
A simple python file for my button game. Includes all files required including the custom graphics file. (graphics.py)

This is a programming exercise from a textbook I am using to teach myself Python. It allows the user to click one of three buttons,
but only one is a "winning" button. After clicking, the game will reveal which button is correct and if the user wins or loses.

Future changes will include adding a running score... and any graphical or UI changes to make the thing look a little more
attractive.
